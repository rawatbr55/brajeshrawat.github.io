import random

# Input team name, batsman names, and initial match details
team_name = input("Write team name: ")
print(" -----------------------------------")
batsman1 = input("Enter the name of Batsman 1: 🏏 ")
print("-------------------------------------")
batsman2 = input("Enter the name of Batsman 2: 🏏 ") 
print("-------------------------------------")
total_runs = int(input("Enter initial runs: 🥎 ")) 
print("-------------------------------------")
total_balls = int(input("Enter total number of balls faced so far: ")) 
print("-------------------------------------")

# Audience reactions
audience_reactions = [
    "The crowd goes wild! 🎉",
    "What a brilliant shot! 👏",
    "Boo! Not good enough! 👎",
    "The crowd is on their feet! 🏟️",
    "A massive six! Amazing! 🌟",
    "Ooooh! Close call! 😱",
    "The batsman is looking confident! 💪",
    "Oh no! What a miss! 😢",
    44"Wicket! Silence falls over the crowd... 😮"
]

# Start the match
x = 1  # Control for the while loop
while x > 0:
    # Calculate overs
    overs = total_balls // 6
    balls_in_over = total_balls % 6

    # Display score
    print("_______________________________________________________")
    print("        ---🏆 CRICKET MATCH SCORE 🏆---")
    print("_______________________________________________________")
    print("                  TEAM: ", team_name)
    print("  🏏 Batsman 1: ", batsman1, "         🏏 Batsman 2: ", batsman2)
    print("_______________________________________________________")
    print("Run: ", total_runs, "    Overs: ", overs, ".", balls_in_over, "   Balls: ", total_balls)
    print("_______________________________________________________")

    # Ask user if they want to continue or stop
    x = int(input("Enter 1 to continue or 0 to stop: ")) 
    print("_______________________________________________________")
    
    # If user wants to continue, update the total runs and balls
    if x > 0:
        runs_scored = int(input("Enter runs scored in the last ball (or enter -1 for Wicket): "))
        
        if runs_scored == -1:  # Handle wicket scenario
            print(f"WICKET! {batsman1 if total_balls % 2 == 0 else batsman2} is out! Silence falls over the crowd... 😮")
            print(random.choice(audience_reactions[-1:]))  # Response for a wicket
        else:
            total_runs += runs_scored
            total_balls += 1
            
            # Check if the runs are odd, change the batsman
            if runs_scored % 2 != 0:
                batsman1, batsman2 = batsman2, batsman1  # Swap the batsmen

            # Simulate audience response based on runs scored
            if runs_scored > 0:
                print(random.choice(audience_reactions[:5]))  # Positive reactions for runs
            elif runs_scored == 0:
                print(random.choice(audience_reactions[5:]))  # Neutral reactions for dot balls

    print("_______________________________________________________")

print("Match Ended!")
